import '../../../services/api_service.dart';

class ClientService {
  /* =======================================================
     🔹 CREATE CLIENT
     POST /clients
     ======================================================= */
  Future<void> createClient({
    required String firstName,
    required String emailAddress,

    String? lastName,
    String? cellphone,
    String? phoneNo1,
    String? phoneNo2,
    String? faxNo,
    String? contactPerson,
    String? customerCode,
    String? companyName,
    String? companyId,
    String? salesManagerId,
    String? einTin,
    String? vatIdentifier,
    String? socialSecurityNumber,
    String? street,
    String? city,
    String? state,
    String? postcode,
    String? country,
  }) async {
    await ApiService.post(
      '/clients',
      {
        'firstName': firstName,
        'emailAddress': emailAddress,
        'lastName': lastName,
        'cellphone': cellphone,
        'phoneNo1': phoneNo1,
        'phoneNo2': phoneNo2,
        'faxNo': faxNo,
        'contactPerson': contactPerson,
        'customerCode': customerCode,
        'companyName': companyName,
        'companyId': companyId,
        'salesManagerId': salesManagerId,
        'einTin': einTin,
        'vatIdentifier': vatIdentifier,
        'socialSecurityNumber': socialSecurityNumber,
        'street': street,
        'city': city,
        'state': state,
        'postcode': postcode,
        'country': country,
      },
    );
  }

  /* =======================================================
     🔹 GET CLIENT LIST
     GET /clients
     ======================================================= */
  Future<List<Map<String, dynamic>>> getClients() async {
    final response = await ApiService.get('/clients');
    final List list = response['clients'] ?? [];

    return list.map<Map<String, dynamic>>((c) {
      return {
        'clientId': c['id'],
        'companyName': c['companyName'],
        'emailAddress': c['emailAddress'],
        'phoneNo1': c['phoneNo1'],
        'status': c['status'],
      };
    }).toList();
  }

  /* =======================================================
     🔹 TOGGLE STATUS
     PATCH /clients/:id/status
     ======================================================= */
  Future<void> toggleStatus({
    required String clientId,
    required bool activate,
  }) async {
    await ApiService.patch(
      '/clients/$clientId/status',
      {
        'status': activate ? 'active' : 'inactive',
      },
    );
  }
}
