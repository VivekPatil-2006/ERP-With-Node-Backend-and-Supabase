import '../../../../services/api_service.dart';

class EnquiryService {
  /* =======================================================
     🔹 GET ENQUIRIES
     GET /api/enquiries
     ======================================================= */
  Future<List<Map<String, dynamic>>> getEnquiries() async {
    final response = await ApiService.get('/enquiries');

    final List list = response['enquiries'] ?? [];

    return list.map<Map<String, dynamic>>((e) {
      return {
        'enquiryId': e['id'],
        'title': e['title'],
        'source': e['source'],
        'status': e['status'] ?? 'raised',
        'createdAt': e['createdAt'],
      };
    }).toList();
  }
}
